# Adobe Payroll

- Category: I promise it's not malware 😈
- Points: 100

## Description

This is a .NET file. Take a look at dotPeek.