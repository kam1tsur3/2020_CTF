#!/bin/zsh
UID=1000
cd /ctf
./bookface
